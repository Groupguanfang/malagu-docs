// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/dev/_dir\",\"_dir\":\"dev\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"开发\",\"icon\":\"i-mdi-microsoft-visual-studio-code\",\"description\":\"为开发者提供的内容。\",\"_id\":\"content:4.dev:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"4.dev/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"zh0UoEByd0\"}";

export { _dir as default };
//# sourceMappingURL=_dir3.mjs.map
