// ROLLUP_NO_REPLACE 
 const _0_oldDocs = "{\"parsed\":{\"_path\":\"/old-docs\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"旧版文档\",\"description\":\"新文档可能更新不及时，你仍可以查看旧版文档。\",\"redirect\":\"https://malagu.cellbang.com\",\"target\":\"_blank\",\"body\":{\"type\":\"root\",\"children\":[],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:0.old-docs.md\",\"_source\":\"content\",\"_file\":\"0.old-docs.md\",\"_extension\":\"md\"},\"hash\":\"9D77ZLy2yU\"}";

export { _0_oldDocs as default };
//# sourceMappingURL=0.old-docs.mjs.map
