// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/guides/_dir\",\"_dir\":\"guides\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"基础\",\"icon\":\"i-ph-rocket\",\"_id\":\"content:1.guides:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"1.guides/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"QgUz5OjWdN\"}";

export { _dir as default };
//# sourceMappingURL=_dir.mjs.map
