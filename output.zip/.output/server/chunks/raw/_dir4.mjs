// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/cloud/_dir\",\"_dir\":\"cloud\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"部署\",\"icon\":\"i-mdi-cloud-upload-outline\",\"_id\":\"content:5.cloud:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"5.cloud/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"iVXosJ564X\"}";

export { _dir as default };
//# sourceMappingURL=_dir4.mjs.map
