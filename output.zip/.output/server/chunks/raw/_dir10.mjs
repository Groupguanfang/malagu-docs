// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/components/database/_dir\",\"_dir\":\"database\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"数据库\",\"icon\":\"i-ph-database\",\"_id\":\"content:2.components:6.database:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"2.components/6.database/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"aywWOyt33P\"}";

export { _dir as default };
//# sourceMappingURL=_dir10.mjs.map
