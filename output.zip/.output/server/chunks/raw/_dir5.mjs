// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/extends/_dir\",\"_dir\":\"extends\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"扩展\",\"icon\":\"i-mdi-puzzle\",\"_id\":\"content:6.extends:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"6.extends/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"Ll6U9aWDWO\"}";

export { _dir as default };
//# sourceMappingURL=_dir5.mjs.map
