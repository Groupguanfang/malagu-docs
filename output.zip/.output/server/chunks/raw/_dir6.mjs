// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/components/cli/_dir\",\"_dir\":\"cli\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"CLI\",\"icon\":\"i-carbon-code\",\"description\":\"Malagu CLI\",\"_id\":\"content:2.components:3.cli:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"2.components/3.cli/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"kM8ODSrKLz\"}";

export { _dir as default };
//# sourceMappingURL=_dir6.mjs.map
