// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/components/core/_dir\",\"_dir\":\"core\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"核心\",\"icon\":\"i-heroicons-cpu-chip\",\"_id\":\"content:2.components:2.core:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"2.components/2.core/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"BLdKnqG1Pp\"}";

export { _dir as default };
//# sourceMappingURL=_dir7.mjs.map
