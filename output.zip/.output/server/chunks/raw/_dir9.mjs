// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/components/backend/_dir\",\"_dir\":\"backend\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"后端\",\"icon\":\"i-mdi-server-network-outline\",\"description\":\"服务端开发相关内容\",\"_id\":\"content:2.components:4.backend:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"2.components/4.backend/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"0X0DuHTKyE\"}";

export { _dir as default };
//# sourceMappingURL=_dir9.mjs.map
