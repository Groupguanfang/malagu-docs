// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/concepts/_dir\",\"_dir\":\"concepts\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"概念\",\"description\":\"本章节主要介绍了一些基础概念，帮助你更好的理解和使用 Malagu。\",\"icon\":\"i-ph-book\",\"_id\":\"content:3.concepts:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"3.concepts/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"t28WW87VQc\"}";

export { _dir as default };
//# sourceMappingURL=_dir2.mjs.map
