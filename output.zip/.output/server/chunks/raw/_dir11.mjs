// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/components/security/_dir\",\"_dir\":\"security\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"安全\",\"icon\":\"i-ph-shield-checkered\",\"_id\":\"content:2.components:7.security:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"2.components/7.security/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"Fkk3iF9YB4\"}";

export { _dir as default };
//# sourceMappingURL=_dir11.mjs.map
