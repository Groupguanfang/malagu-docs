// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/components/frontend/_dir\",\"_dir\":\"frontend\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"前端\",\"icon\":\"i-mdi-web\",\"description\":\"前端开发相关内容\",\"_id\":\"content:2.components:5.frontend:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"2.components/5.frontend/_dir.yml\",\"_extension\":\"yml\"},\"hash\":\"b75KSBoVu5\"}";

export { _dir as default };
//# sourceMappingURL=_dir8.mjs.map
