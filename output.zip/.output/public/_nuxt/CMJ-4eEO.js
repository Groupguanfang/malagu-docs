import{d as n,U as e}from"./Co7mPyGN.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
