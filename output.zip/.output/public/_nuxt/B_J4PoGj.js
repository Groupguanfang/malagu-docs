import{d as n}from"./Co7mPyGN.js";const m=n({name:"OgImageDynamic",async setup(a,{attrs:e}){return()=>null}});export{m as default};
