import{d as e}from"./Co7mPyGN.js";const o=e({name:"OgImage",async setup(n,{attrs:t}){return()=>null}});export{o as default};
