import{d as e}from"./Co7mPyGN.js";const o=e({name:"OgImageCached",async setup(a,{attrs:t}){return()=>null}});export{o as default};
