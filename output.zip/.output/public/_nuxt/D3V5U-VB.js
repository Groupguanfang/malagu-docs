import{d as t}from"./Co7mPyGN.js";const o=t({name:"OgImageWithoutCache",async setup(e,{attrs:a}){return()=>null}});export{o as default};
