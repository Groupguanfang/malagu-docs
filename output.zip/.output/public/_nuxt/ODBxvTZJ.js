import{d as t}from"./Co7mPyGN.js";const o=t({name:"OgImageStatic",async setup(a,{attrs:e}){return()=>null}});export{o as default};
